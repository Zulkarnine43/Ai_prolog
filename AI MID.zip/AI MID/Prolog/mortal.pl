human(socrates).
human(gates).
human(paul).
mortal(rahim).
mortal(karim).

mortal(X):-human(X).
