a:- b.
c:- d,e,f.
g(X):-h(X,Y), not(f(Y)).
