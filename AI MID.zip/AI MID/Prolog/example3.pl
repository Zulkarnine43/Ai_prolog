dog(fido).
dog(rover).
dog(tom).
dog(henry).
cat(harry).
cat(mary).
cat(bill).
cat(steve).

animal(X):- dog(X).
