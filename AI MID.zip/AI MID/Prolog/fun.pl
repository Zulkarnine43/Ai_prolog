fun(X):-
       red(X).
       car(X).

fun(X):-
       blue(X).
       bike(X).

fun(ice_cream).
