dog(fido).
cat(felix).
animal(X,Y):- dog(X),cat(Y).
