eats(fred,mangoes).
