dog(fido).

cat(mary).
dog(rover).
dog(tom).
cat(harry).
dog(henry).
cat(bill).
cat(steve).
animal(X):- dog(X),cat(X).
