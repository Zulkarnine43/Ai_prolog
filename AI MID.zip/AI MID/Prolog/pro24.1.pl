sky(blue).
Tree(green).
Computer(machine).
Winter(cold).
Eye(black).
