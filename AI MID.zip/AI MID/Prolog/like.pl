likes(john,food).
likes(john,juice).
likes(mary,food).
likes(john,mary).
