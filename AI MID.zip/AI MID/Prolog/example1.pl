sky(blue).
tree(green).
computer(machine).
winter(cold).
eye(black).
