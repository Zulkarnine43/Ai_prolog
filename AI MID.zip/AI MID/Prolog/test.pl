s is 2+2.
