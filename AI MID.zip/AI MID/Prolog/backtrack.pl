bird(sparrow,steve).
bird(penguin, sweety).
bird(penguin, jones).

