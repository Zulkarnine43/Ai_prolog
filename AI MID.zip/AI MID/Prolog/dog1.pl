dog(fido).
cat(felix).
monkey(galiver).
animal(X):- dog(X).
