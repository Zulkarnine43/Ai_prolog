barking(dog).
likes(jaya, Food):- delicious(Food).
