sky(blue).
tree(green).
computer(machine).
winter(cold).
winter(medium).
eye(black).
