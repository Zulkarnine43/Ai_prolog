loves(john,mary).
loves(fred,hobbies).

