woman(mia).
woman(jody).
woman(yolanda).
woman(sofia).
playsAirGuitar(jody).
party.
